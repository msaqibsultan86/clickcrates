package studio.spark.clickcrates.hologram;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.data.DataManager;
import studio.spark.clickcrates.model.Crate;
import studio.spark.clickcrates.util.Text;

import java.util.List;
import java.util.Map;

public class HologramManager {
    private final ClickCrates plugin;
    private final NamespacedKey tag;

    public HologramManager(ClickCrates plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "cc_holo");
    }

    public void spawnAll() {
        for (Map.Entry<String, String> e : plugin.data().allBlocks().entrySet()) {
            Location l = DataManager.fromKey(e.getKey());
            Crate c = plugin.crates().get(e.getValue());
            if (l != null && c != null) spawn(l, c);
        }
    }

    public void spawn(Location block, Crate crate) {
        if (!crate.hologramEnabled) return;
        block.getChunk().load();
        remove(block); // avoid dupes
        Location loc = block.clone().add(0.5, crate.hologramOffsetY, 0.5);
        Component text = null;
        boolean first = true;
        for (String line : crate.hologramLines) {
            if (line.contains("%player_keys%")) continue; // global holo can't be per-player
            Component c = Text.item(line.replace("%crate%", crate.id));
            text = first ? c : text.append(Component.newline()).append(c);
            first = false;
        }
        if (text == null) text = Text.item("&f" + crate.id.toUpperCase());
        final Component ftext = text;
        loc.getWorld().spawn(loc, TextDisplay.class, td -> {
            td.text(ftext);
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(true);
            td.setDefaultBackground(false);
            td.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            td.setAlignment(TextDisplay.TextAlignment.CENTER);
            td.getPersistentDataContainer().set(tag, PersistentDataType.STRING, DataManager.key(block));
        });
    }

    public void remove(Location block) {
        block.getChunk().load();
        String key = DataManager.key(block);
        for (Entity e : block.getWorld().getNearbyEntities(block.clone().add(0.5, 1, 0.5), 2, 3, 2)) {
            if (!(e instanceof TextDisplay)) continue;
            String v = e.getPersistentDataContainer().get(tag, PersistentDataType.STRING);
            if (key.equals(v)) e.remove();
        }
    }

    public void removeAll() {
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (e instanceof TextDisplay && e.getPersistentDataContainer().has(tag, PersistentDataType.STRING))
                    e.remove();
    }
}
