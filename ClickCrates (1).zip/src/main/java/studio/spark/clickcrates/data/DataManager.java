package studio.spark.clickcrates.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import studio.spark.clickcrates.ClickCrates;

import java.io.File;
import java.util.*;

public class DataManager {
    private final ClickCrates plugin;
    private File file;
    private FileConfiguration cfg;

    // "world,x,y,z" -> crateId
    private final Map<String, String> blocks = new HashMap<>();
    // uuid -> (crateId -> count)
    private final Map<UUID, Map<String, Integer>> keys = new HashMap<>();

    public DataManager(ClickCrates plugin) { this.plugin = plugin; load(); }

    public void load() {
        blocks.clear(); keys.clear();
        file = new File(plugin.getDataFolder(), "data.yml");
        if (!file.exists()) { try { file.createNewFile(); } catch (Exception ignored) {} }
        cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection b = cfg.getConfigurationSection("blocks");
        if (b != null) for (String k : b.getKeys(false)) blocks.put(k, b.getString(k));
        ConfigurationSection k = cfg.getConfigurationSection("keys");
        if (k != null) {
            for (String uid : k.getKeys(false)) {
                ConfigurationSection cs = k.getConfigurationSection(uid);
                if (cs == null) continue;
                Map<String, Integer> map = new HashMap<>();
                for (String crate : cs.getKeys(false)) map.put(crate, cs.getInt(crate));
                try { keys.put(UUID.fromString(uid), map); } catch (Exception ignored) {}
            }
        }
    }

    public void save() {
        cfg.set("blocks", null);
        for (Map.Entry<String, String> e : blocks.entrySet()) cfg.set("blocks." + e.getKey(), e.getValue());
        cfg.set("keys", null);
        for (Map.Entry<UUID, Map<String, Integer>> e : keys.entrySet())
            for (Map.Entry<String, Integer> c : e.getValue().entrySet())
                cfg.set("keys." + e.getKey() + "." + c.getKey(), c.getValue());
        try { cfg.save(file); } catch (Exception ex) { plugin.getLogger().warning("data.yml save failed: " + ex.getMessage()); }
    }

    public static String key(Location l) {
        return l.getWorld().getName() + "," + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ();
    }
    public static Location fromKey(String k) {
        String[] p = k.split(",");
        World w = Bukkit.getWorld(p[0]);
        if (w == null) return null;
        return new Location(w, Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
    }

    // ---- blocks ----
    public void setBlock(Location l, String crate) { blocks.put(key(l), crate.toLowerCase()); save(); }
    public void removeBlock(Location l) { blocks.remove(key(l)); save(); }
    public String crateAt(Location l) { return blocks.get(key(l)); }
    public Map<String, String> allBlocks() { return blocks; }

    // ---- keys ----
    public int getKeys(UUID id, String crate) {
        return keys.getOrDefault(id, Collections.emptyMap()).getOrDefault(crate.toLowerCase(), 0);
    }
    public void addKeys(UUID id, String crate, int amount) {
        keys.computeIfAbsent(id, k -> new HashMap<>()).merge(crate.toLowerCase(), amount, Integer::sum);
        save();
    }
    public boolean takeKey(UUID id, String crate) {
        Map<String, Integer> m = keys.get(id);
        if (m == null) return false;
        int cur = m.getOrDefault(crate.toLowerCase(), 0);
        if (cur <= 0) return false;
        m.put(crate.toLowerCase(), cur - 1);
        save();
        return true;
    }
    public void setKeys(UUID id, String crate, int amount) {
        keys.computeIfAbsent(id, k -> new HashMap<>()).put(crate.toLowerCase(), Math.max(0, amount));
        save();
    }
}
