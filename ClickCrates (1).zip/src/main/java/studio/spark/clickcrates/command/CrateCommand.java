package studio.spark.clickcrates.command;

import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.model.Crate;

import java.util.ArrayList;
import java.util.List;

public class CrateCommand implements TabExecutor {
    private final ClickCrates plugin;
    public CrateCommand(ClickCrates plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command command, @NotNull String label, @NotNull String[] a) {
        if (a.length == 0) { s.sendMessage(plugin.messages().plain("usage")); return true; }
        String sub = a[0].toLowerCase();

        if (!s.hasPermission("clickcrates.admin")) { s.sendMessage(plugin.messages().msg("no-permission")); return true; }

        switch (sub) {
            case "reload" -> { plugin.reloadAll(); s.sendMessage(plugin.messages().msg("reloaded")); }
            case "list" -> s.sendMessage(plugin.messages().msg("crates-list", "crates", String.join(", ", plugin.crates().ids())));
            case "create" -> {
                if (a.length < 2) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                String id = a[1].toLowerCase();
                if (plugin.crates().exists(id)) { s.sendMessage(plugin.messages().msg("crate-exists")); return true; }
                plugin.crates().createEmpty(id);
                s.sendMessage(plugin.messages().msg("crate-created", "crate", id));
            }
            case "remove" -> {
                if (a.length < 2) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                String id = a[1].toLowerCase();
                if (!plugin.crates().exists(id)) { s.sendMessage(plugin.messages().msg("unknown-crate", "crate", id)); return true; }
                // remove blocks + holos for this crate
                new ArrayList<>(plugin.data().allBlocks().entrySet()).forEach(en -> {
                    if (en.getValue().equalsIgnoreCase(id)) {
                        var loc = studio.spark.clickcrates.data.DataManager.fromKey(en.getKey());
                        if (loc != null) { plugin.holograms().remove(loc); plugin.data().removeBlock(loc); }
                    }
                });
                plugin.crates().remove(id);
                s.sendMessage(plugin.messages().msg("crate-removed", "crate", id));
            }
            case "block" -> {
                if (!(s instanceof Player p)) { s.sendMessage(plugin.messages().msg("player-only")); return true; }
                if (a.length < 2) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                String id = a[1].toLowerCase();
                Crate crate = plugin.crates().get(id);
                if (crate == null) { p.sendMessage(plugin.messages().msg("unknown-crate", "crate", id)); return true; }
                Block b = p.getTargetBlockExact(6);
                if (b == null) { p.sendMessage(plugin.messages().plain("usage")); return true; }
                plugin.data().setBlock(b.getLocation(), id);
                plugin.holograms().spawn(b.getLocation(), crate);
                p.sendMessage(plugin.messages().msg("block-set", "crate", id));
            }
            case "give" -> {
                if (a.length < 4) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                Player t = plugin.getServer().getPlayerExact(a[1]);
                if (t == null) { s.sendMessage(plugin.messages().msg("player-only")); return true; }
                String id = a[2].toLowerCase();
                if (!plugin.crates().exists(id)) { s.sendMessage(plugin.messages().msg("unknown-crate", "crate", id)); return true; }
                int amt = parse(a[3], 1);
                plugin.data().addKeys(t.getUniqueId(), id, amt);
                t.sendMessage(plugin.messages().msg("key-received", "amount", String.valueOf(amt), "crate", id));
            }
            case "removekey" -> {
                if (a.length < 4) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                Player t = plugin.getServer().getPlayerExact(a[1]);
                if (t == null) { s.sendMessage(plugin.messages().msg("player-only")); return true; }
                String id = a[2].toLowerCase();
                int amt = parse(a[3], 1);
                int cur = plugin.data().getKeys(t.getUniqueId(), id);
                plugin.data().setKeys(t.getUniqueId(), id, Math.max(0, cur - amt));
                s.sendMessage(plugin.messages().msg("key-taken", "amount", String.valueOf(amt), "crate", id, "player", t.getName()));
            }
            case "keyall" -> {
                if (a.length < 3) { s.sendMessage(plugin.messages().plain("usage")); return true; }
                String id = a[1].toLowerCase();
                if (!plugin.crates().exists(id)) { s.sendMessage(plugin.messages().msg("unknown-crate", "crate", id)); return true; }
                int amt = parse(a[2], 1);
                int n = 0;
                for (Player pl : plugin.getServer().getOnlinePlayers()) {
                    plugin.data().addKeys(pl.getUniqueId(), id, amt);
                    pl.sendMessage(plugin.messages().msg("key-received", "amount", String.valueOf(amt), "crate", id));
                    n++;
                }
                s.sendMessage(plugin.messages().msg("keyall", "amount", String.valueOf(amt), "crate", id, "players", String.valueOf(n)));
            }
            default -> s.sendMessage(plugin.messages().plain("usage"));
        }
        return true;
    }

    private int parse(String s, int def) { try { return Integer.parseInt(s); } catch (Exception e) { return def; } }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender s, @NotNull Command c, @NotNull String l, @NotNull String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("clickcrates.admin")) return out;
        if (a.length == 1) {
            for (String o : List.of("list", "create", "remove", "block", "give", "keyall", "removekey", "reload"))
                if (o.startsWith(a[0].toLowerCase())) out.add(o);
        } else if (a.length == 2 && List.of("remove", "block", "keyall").contains(a[0].toLowerCase())) {
            out.addAll(plugin.crates().ids());
        } else if (a.length == 3 && List.of("give", "removekey").contains(a[0].toLowerCase())) {
            out.addAll(plugin.crates().ids());
        }
        return out;
    }
}
