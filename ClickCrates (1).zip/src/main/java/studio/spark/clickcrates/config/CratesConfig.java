package studio.spark.clickcrates.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.model.Crate;
import studio.spark.clickcrates.model.Reward;

import java.io.File;
import java.util.*;

public class CratesConfig {
    private final ClickCrates plugin;
    private final LinkedHashMap<String, Crate> crates = new LinkedHashMap<>();
    private File file;
    private FileConfiguration cfg;

    public CratesConfig(ClickCrates plugin) { this.plugin = plugin; load(); }

    public void load() {
        crates.clear();
        file = new File(plugin.getDataFolder(), "crates.yml");
        if (!file.exists()) plugin.saveResource("crates.yml", false);
        cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("Crates");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            Crate crate = new Crate(id.toLowerCase());
            crate.rows = c.getInt("rows", 3);
            crate.title = c.getString("title", "&8Crate");
            crate.fillerEnabled = c.getBoolean("fillerEnabled", true);
            crate.fillerMaterial = c.getString("fillerMaterial", "BLACK_STAINED_GLASS_PANE");
            crate.fillerLore = c.getStringList("fillerLore");
            ConfigurationSection holo = c.getConfigurationSection("Hologram");
            if (holo != null) {
                crate.hologramEnabled = holo.getBoolean("enabled", true);
                crate.hologramOffsetY = holo.getDouble("offsetY", 1.2);
                crate.hologramLines = holo.getStringList("lines");
            }
            ConfigurationSection items = c.getConfigurationSection("Items");
            if (items != null) {
                for (String ik : items.getKeys(false)) {
                    ConfigurationSection it = items.getConfigurationSection(ik);
                    if (it == null) continue;
                    crate.rewards.add(new Reward(
                        it.getString("material", "STONE"),
                        it.getString("displayname", null),
                        it.getInt("amount", 1),
                        it.getInt("slot", 0),
                        it.getBoolean("giveitem", true),
                        it.getString("command", ""),
                        it.getStringList("lore"),
                        it.getStringList("enchantments")
                    ));
                }
            }
            crates.put(crate.id, crate);
        }
    }

    public Crate get(String id) { return id == null ? null : crates.get(id.toLowerCase()); }
    public Collection<Crate> all() { return crates.values(); }
    public Set<String> ids() { return crates.keySet(); }
    public boolean exists(String id) { return crates.containsKey(id.toLowerCase()); }

    public void createEmpty(String id) {
        cfg.set("Crates." + id + ".rows", 3);
        cfg.set("Crates." + id + ".title", "&8" + id);
        cfg.set("Crates." + id + ".fillerEnabled", true);
        cfg.set("Crates." + id + ".fillerMaterial", "BLACK_STAINED_GLASS_PANE");
        cfg.set("Crates." + id + ".Hologram.enabled", true);
        cfg.set("Crates." + id + ".Hologram.offsetY", 1.2);
        cfg.set("Crates." + id + ".Hologram.lines", List.of("&f" + id.toUpperCase() + " CRATE", "&eRight-click to open"));
        cfg.set("Crates." + id + ".Items.Item1.material", "DIAMOND");
        cfg.set("Crates." + id + ".Items.Item1.displayname", "&bExample Reward");
        cfg.set("Crates." + id + ".Items.Item1.amount", 1);
        cfg.set("Crates." + id + ".Items.Item1.slot", 13);
        cfg.set("Crates." + id + ".Items.Item1.giveitem", true);
        cfg.set("Crates." + id + ".Items.Item1.command", "");
        save();
        load();
    }

    public void remove(String id) { cfg.set("Crates." + id.toLowerCase(), null); save(); load(); }

    public void save() {
        try { cfg.save(file); } catch (Exception e) { plugin.getLogger().warning("crates.yml save failed: " + e.getMessage()); }
    }
}
