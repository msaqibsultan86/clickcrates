package studio.spark.clickcrates.config;

import net.kyori.adventure.text.Component;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.util.Text;

public class Messages {
    private final ClickCrates plugin;
    public Messages(ClickCrates plugin) { this.plugin = plugin; }

    private String prefix() { return plugin.getConfig().getString("prefix", ""); }
    public String raw(String key) { return plugin.getConfig().getString("messages." + key, key); }

    public Component msg(String key, String... repl) {
        return Text.color(prefix() + apply(raw(key), repl));
    }
    public Component plain(String key, String... repl) {
        return Text.color(apply(raw(key), repl));
    }
    public static String apply(String s, String... repl) {
        for (int i = 0; i + 1 < repl.length; i += 2) s = s.replace("%" + repl[i] + "%", repl[i + 1]);
        return s;
    }
}
