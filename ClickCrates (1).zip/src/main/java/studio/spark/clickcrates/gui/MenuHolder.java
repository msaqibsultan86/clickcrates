package studio.spark.clickcrates.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public class MenuHolder implements InventoryHolder {
    public enum Type { CRATE, CONFIRM }
    private Inventory inventory;
    public final Type type;
    public final String crateId;
    public final int rewardIndex; // CONFIRM

    public MenuHolder(Type type, String crateId, int rewardIndex) {
        this.type = type; this.crateId = crateId; this.rewardIndex = rewardIndex;
    }
    public void setInventory(Inventory inv) { this.inventory = inv; }
    @Override public @NotNull Inventory getInventory() { return inventory; }
}
