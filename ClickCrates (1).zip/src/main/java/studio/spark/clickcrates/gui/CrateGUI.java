package studio.spark.clickcrates.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.model.Crate;
import studio.spark.clickcrates.model.Reward;
import studio.spark.clickcrates.util.Items;
import studio.spark.clickcrates.util.Text;

import java.util.ArrayList;
import java.util.List;

public class CrateGUI {
    private final ClickCrates plugin;
    public CrateGUI(ClickCrates plugin) { this.plugin = plugin; }

    public void openCrate(Player p, Crate crate) {
        int size = Math.max(9, Math.min(54, crate.rows * 9));
        MenuHolder h = new MenuHolder(MenuHolder.Type.CRATE, crate.id, -1);
        Inventory inv = Bukkit.createInventory(h, size, Text.color(crate.title));
        h.setInventory(inv);
        if (crate.fillerEnabled) {
            Material fm = Items.mat(crate.fillerMaterial, Material.BLACK_STAINED_GLASS_PANE);
            List<net.kyori.adventure.text.Component> flore = new ArrayList<>();
            for (String l : crate.fillerLore) flore.add(Text.item(l));
            ItemStack filler = Items.simple(fm, Text.item(" "), flore.isEmpty() ? null : flore);
            for (int i = 0; i < size; i++) inv.setItem(i, filler);
        }
        for (int i = 0; i < crate.rewards.size(); i++) {
            Reward r = crate.rewards.get(i);
            int slot = r.slot;
            if (slot < 0 || slot >= size) continue;
            inv.setItem(slot, Items.icon(r));
        }
        p.openInventory(inv);
    }

    public void openConfirm(Player p, Crate crate, int rewardIndex) {
        if (rewardIndex < 0 || rewardIndex >= crate.rewards.size()) return;
        int rows = plugin.getConfig().getInt("confirm-menu.rows", 3);
        MenuHolder h = new MenuHolder(MenuHolder.Type.CONFIRM, crate.id, rewardIndex);
        Inventory inv = Bukkit.createInventory(h, rows * 9, Text.color(plugin.getConfig().getString("confirm-menu.title", "&8Confirm")));
        h.setInventory(inv);
        int cSlot = plugin.getConfig().getInt("confirm-menu.confirm-slot", 15);
        int dSlot = plugin.getConfig().getInt("confirm-menu.decline-slot", 11);
        int iSlot = plugin.getConfig().getInt("confirm-menu.item-slot", 13);
        Material cMat = Items.mat(plugin.getConfig().getString("confirm-menu.confirm-material", "LIME_STAINED_GLASS_PANE"), Material.LIME_STAINED_GLASS_PANE);
        Material dMat = Items.mat(plugin.getConfig().getString("confirm-menu.decline-material", "RED_STAINED_GLASS_PANE"), Material.RED_STAINED_GLASS_PANE);
        inv.setItem(cSlot, Items.simple(cMat, Text.item(plugin.getConfig().getString("confirm-menu.confirm-name", "&aConfirm")), null));
        inv.setItem(dSlot, Items.simple(dMat, Text.item(plugin.getConfig().getString("confirm-menu.decline-name", "&cDecline")), null));
        inv.setItem(iSlot, Items.icon(crate.rewards.get(rewardIndex)));
        p.openInventory(inv);
    }
}
