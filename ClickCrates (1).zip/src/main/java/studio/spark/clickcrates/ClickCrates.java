package studio.spark.clickcrates;

import org.bukkit.plugin.java.JavaPlugin;
import studio.spark.clickcrates.command.CrateCommand;
import studio.spark.clickcrates.config.CratesConfig;
import studio.spark.clickcrates.config.Messages;
import studio.spark.clickcrates.data.DataManager;
import studio.spark.clickcrates.gui.CrateGUI;
import studio.spark.clickcrates.hologram.HologramManager;
import studio.spark.clickcrates.listener.BlockListener;
import studio.spark.clickcrates.listener.GuiListener;

public class ClickCrates extends JavaPlugin {
    private Messages messages;
    private CratesConfig crates;
    private DataManager data;
    private HologramManager holograms;
    private CrateGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.messages = new Messages(this);
        this.crates = new CratesConfig(this);
        this.data = new DataManager(this);
        this.holograms = new HologramManager(this);
        this.gui = new CrateGUI(this);

        CrateCommand cmd = new CrateCommand(this);
        getCommand("crate").setExecutor(cmd);
        getCommand("crate").setTabCompleter(cmd);

        getServer().getPluginManager().registerEvents(new BlockListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        // spawn holograms once the server is fully up
        getServer().getScheduler().runTaskLater(this, () -> {
            holograms.removeAll();
            holograms.spawnAll();
        }, 40L);

        getLogger().info("ClickCrates enabled.");
    }

    @Override
    public void onDisable() {
        if (holograms != null) holograms.removeAll();
        if (data != null) data.save();
    }

    public void reloadAll() {
        reloadConfig();
        crates.load();
        data.load();
        holograms.removeAll();
        holograms.spawnAll();
    }

    public Messages messages()      { return messages; }
    public CratesConfig crates()    { return crates; }
    public DataManager data()       { return data; }
    public HologramManager holograms() { return holograms; }
    public CrateGUI gui()           { return gui; }
}
