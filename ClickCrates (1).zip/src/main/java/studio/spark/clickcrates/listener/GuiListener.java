package studio.spark.clickcrates.listener;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.gui.MenuHolder;
import studio.spark.clickcrates.model.Crate;
import studio.spark.clickcrates.model.Reward;
import studio.spark.clickcrates.util.Items;

import java.util.List;

public class GuiListener implements Listener {
    private final ClickCrates plugin;
    public GuiListener(ClickCrates plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (!(h instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;

        Crate crate = plugin.crates().get(holder.crateId);
        if (crate == null) { p.closeInventory(); return; }
        int slot = e.getRawSlot();

        if (holder.type == MenuHolder.Type.CRATE) {
            for (int i = 0; i < crate.rewards.size(); i++) {
                if (crate.rewards.get(i).slot == slot) {
                    p.playSound(p.getLocation(), sound("click", Sound.UI_BUTTON_CLICK), 0.6f, 1.4f);
                    plugin.gui().openConfirm(p, crate, i);
                    return;
                }
            }
            return;
        }

        // CONFIRM
        int cSlot = plugin.getConfig().getInt("confirm-menu.confirm-slot", 15);
        int dSlot = plugin.getConfig().getInt("confirm-menu.decline-slot", 11);
        if (slot == dSlot) {
            p.playSound(p.getLocation(), sound("click", Sound.UI_BUTTON_CLICK), 0.6f, 1.1f);
            plugin.gui().openCrate(p, crate);
            return;
        }
        if (slot == cSlot) {
            claim(p, crate, holder.rewardIndex);
        }
    }

    private void claim(Player p, Crate crate, int index) {
        if (index < 0 || index >= crate.rewards.size()) { p.closeInventory(); return; }
        if (!plugin.data().takeKey(p.getUniqueId(), crate.id)) {
            p.sendMessage(plugin.messages().msg("no-keys", "crate", crate.id));
            p.closeInventory();
            return;
        }
        Reward r = crate.rewards.get(index);
        if (r.giveItem) {
            List<ItemStack> items = Items.reward(r);
            var leftover = p.getInventory().addItem(items.toArray(new ItemStack[0]));
            if (!leftover.isEmpty()) {
                leftover.values().forEach(is -> p.getWorld().dropItemNaturally(p.getLocation(), is));
                p.sendMessage(plugin.messages().msg("inventory-full"));
            }
        }
        if (r.command != null && !r.command.isBlank()) {
            String cmd = r.command.replace("%player%", p.getName());
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), cmd);
        }
        String rewardName = r.displayName != null ? r.displayName : r.material;
        p.sendMessage(plugin.messages().msg("claimed", "reward", rewardName, "crate", crate.id));
        p.playSound(p.getLocation(), sound("claim", Sound.ENTITY_EXPERIENCE_ORB_PICKUP), 1f, 1.2f);

        String after = plugin.getConfig().getString("after-claim", "CLOSE");
        if ("REOPEN".equalsIgnoreCase(after) && plugin.data().getKeys(p.getUniqueId(), crate.id) > 0)
            plugin.gui().openCrate(p, crate);
        else
            p.closeInventory();
    }

    private Sound sound(String key, Sound def) {
        try { return Sound.valueOf(plugin.getConfig().getString("sounds." + key, def.name())); }
        catch (Exception e) { return def; }
    }
}
