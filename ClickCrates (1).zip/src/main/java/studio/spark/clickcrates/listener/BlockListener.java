package studio.spark.clickcrates.listener;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import studio.spark.clickcrates.ClickCrates;
import studio.spark.clickcrates.model.Crate;

public class BlockListener implements Listener {
    private final ClickCrates plugin;
    public BlockListener(ClickCrates plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Location loc = e.getClickedBlock().getLocation();
        String crateId = plugin.data().crateAt(loc);
        if (crateId == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        Crate crate = plugin.crates().get(crateId);
        if (crate == null) { p.sendMessage(plugin.messages().msg("unknown-crate", "crate", crateId)); return; }
        if (!p.hasPermission("clickcrates.use")) { p.sendMessage(plugin.messages().msg("no-permission")); return; }
        if (plugin.data().getKeys(p.getUniqueId(), crateId) <= 0) {
            p.sendMessage(plugin.messages().msg("no-keys", "crate", crate.id));
            p.playSound(p.getLocation(), sound("no-key", Sound.ENTITY_VILLAGER_NO), 1f, 1f);
            return;
        }
        p.playSound(p.getLocation(), sound("open", Sound.BLOCK_CHEST_OPEN), 1f, 1f);
        plugin.gui().openCrate(p, crate);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Location loc = e.getBlock().getLocation();
        String crateId = plugin.data().crateAt(loc);
        if (crateId == null) return;
        Player p = e.getPlayer();
        if (p.hasPermission("clickcrates.admin") && p.isSneaking()) {
            plugin.data().removeBlock(loc);
            plugin.holograms().remove(loc);
            p.sendMessage(plugin.messages().msg("block-removed"));
            return; // allow break
        }
        e.setCancelled(true);
        p.sendMessage(plugin.messages().msg("not-a-crate-block"));
    }

    private Sound sound(String key, Sound def) {
        try { return Sound.valueOf(plugin.getConfig().getString("sounds." + key, def.name())); }
        catch (Exception e) { return def; }
    }
}
