package studio.spark.clickcrates.model;

import java.util.List;

public class Reward {
    public final String material;
    public final String displayName;
    public final int amount;
    public final int slot;
    public final boolean giveItem;
    public final String command;
    public final List<String> lore;
    public final List<String> enchants;

    public Reward(String material, String displayName, int amount, int slot,
                  boolean giveItem, String command, List<String> lore, List<String> enchants) {
        this.material = material; this.displayName = displayName; this.amount = amount;
        this.slot = slot; this.giveItem = giveItem; this.command = command;
        this.lore = lore; this.enchants = enchants;
    }
}
