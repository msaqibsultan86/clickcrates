package studio.spark.clickcrates.model;

import java.util.ArrayList;
import java.util.List;

public class Crate {
    public final String id;
    public int rows = 3;
    public String title = "&8Crate";
    public boolean fillerEnabled = true;
    public String fillerMaterial = "BLACK_STAINED_GLASS_PANE";
    public List<String> fillerLore = new ArrayList<>();
    public boolean hologramEnabled = true;
    public double hologramOffsetY = 1.2;
    public List<String> hologramLines = new ArrayList<>();
    public final List<Reward> rewards = new ArrayList<>();

    public Crate(String id) { this.id = id; }
}
