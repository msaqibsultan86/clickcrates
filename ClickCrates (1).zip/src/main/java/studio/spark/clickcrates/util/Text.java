package studio.spark.clickcrates.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Text {
    private static final Pattern HEX = Pattern.compile("&#([0-9A-Fa-f]{6})");
    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();
    private Text() {}

    public static Component color(String s) {
        if (s == null) return Component.empty();
        Matcher m = HEX.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            StringBuilder rep = new StringBuilder("&x");
            for (char c : m.group(1).toCharArray()) rep.append('&').append(c);
            m.appendReplacement(sb, rep.toString());
        }
        m.appendTail(sb);
        return LEGACY.deserialize(sb.toString());
    }

    public static Component item(String s) {
        return color(s).decoration(TextDecoration.ITALIC, false);
    }
}
