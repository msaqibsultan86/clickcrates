package studio.spark.clickcrates.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import studio.spark.clickcrates.model.Reward;

import java.util.ArrayList;
import java.util.List;

public final class Items {
    private Items() {}

    public static Material mat(String s, Material def) {
        if (s == null) return def;
        Material m = Material.matchMaterial(s.toUpperCase());
        return m == null ? def : m;
    }

    public static ItemStack simple(Material m, Component name, List<Component> lore) {
        ItemStack is = new ItemStack(m);
        ItemMeta meta = is.getItemMeta();
        if (name != null) meta.displayName(name);
        if (lore != null) meta.lore(lore);
        is.setItemMeta(meta);
        return is;
    }

    /** Display icon for a reward (shown in the crate GUI). */
    public static ItemStack icon(Reward r) {
        Material m = mat(r.material, Material.STONE);
        ItemStack is = new ItemStack(m, Math.max(1, Math.min(64, r.amount)));
        ItemMeta meta = is.getItemMeta();
        if (r.displayName != null) meta.displayName(Text.item(r.displayName));
        List<Component> lore = new ArrayList<>();
        if (r.lore != null) for (String l : r.lore) lore.add(Text.item(l));
        if (!lore.isEmpty()) meta.lore(lore);
        is.setItemMeta(meta);
        applyEnchants(is, r.enchants);
        return is;
    }

    /** The actual reward item(s) given to the player. */
    public static List<ItemStack> reward(Reward r) {
        List<ItemStack> out = new ArrayList<>();
        Material m = mat(r.material, Material.STONE);
        int remaining = Math.max(1, r.amount);
        int max = m.getMaxStackSize();
        while (remaining > 0) {
            int s = Math.min(max, remaining);
            ItemStack is = new ItemStack(m, s);
            ItemMeta meta = is.getItemMeta();
            if (r.displayName != null) meta.displayName(Text.item(r.displayName));
            List<Component> lore = new ArrayList<>();
            if (r.lore != null) for (String l : r.lore) lore.add(Text.item(l));
            if (!lore.isEmpty()) meta.lore(lore);
            is.setItemMeta(meta);
            applyEnchants(is, r.enchants);
            out.add(is);
            remaining -= s;
        }
        return out;
    }

    private static void applyEnchants(ItemStack is, List<String> enchants) {
        if (enchants == null) return;
        for (String e : enchants) {
            String[] parts = e.split(";");
            if (parts.length < 1) continue;
            String name = parts[0].trim().toLowerCase();
            int lvl = 1;
            if (parts.length >= 2) { try { lvl = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) {} }
            Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(name));
            if (ench != null) is.addUnsafeEnchantment(ench, lvl);
        }
    }
}
