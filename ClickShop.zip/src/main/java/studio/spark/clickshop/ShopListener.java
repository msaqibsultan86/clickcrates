package studio.spark.clickshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/** Handles clicks in the shop menus: open categories, buy, sell. */
public class ShopListener implements Listener {

    private final ClickShop plugin;

    public ShopListener(ClickShop plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = e.getView().getTitle();
        ShopManager sm = plugin.getShopManager();

        // ----- main menu -----
        if (title.equals(ShopManager.MAIN_TITLE)) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR) return;
            // match category by its icon slot
            for (ShopManager.Category cat : sm.getCategories().values()) {
                if (cat.slot == e.getRawSlot()) {
                    sm.openCategory(player, cat.id);
                    return;
                }
            }
            return;
        }

        // ----- category view -----
        ShopManager.Category cat = sm.categoryByTitle(title);
        if (cat == null) return;
        e.setCancelled(true);

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        // find the shop item by material
        ShopManager.ShopItem item = null;
        for (ShopManager.ShopItem si : cat.items) {
            if (si.material() == clicked.getType()) { item = si; break; }
        }
        if (item == null) return;

        Economy eco = plugin.getEconomy();

        if (e.isLeftClick()) {          // BUY 1
            if (item.buyPrice() < 0) { player.sendMessage("§cThis item can't be bought."); return; }
            if (eco.getBalance(player) < item.buyPrice()) {
                player.sendMessage("§cYou need " + ShopManager.fmt(item.buyPrice()) + " to buy that.");
                return;
            }
            eco.withdrawPlayer(player, item.buyPrice());
            player.getInventory().addItem(new ItemStack(item.material(), 1));
            player.sendMessage("§aBought §f1x " + pretty(item.material())
                    + " §afor §f" + ShopManager.fmt(item.buyPrice()));
        } else if (e.isRightClick()) {  // SELL 1
            if (item.sellPrice() < 0) { player.sendMessage("§cThis item can't be sold."); return; }
            if (!player.getInventory().containsAtLeast(new ItemStack(item.material()), 1)) {
                player.sendMessage("§cYou don't have any " + pretty(item.material()) + " to sell.");
                return;
            }
            player.getInventory().removeItem(new ItemStack(item.material(), 1));
            eco.depositPlayer(player, item.sellPrice());
            player.sendMessage("§eSold §f1x " + pretty(item.material())
                    + " §efor §f" + ShopManager.fmt(item.sellPrice()));
        }
    }

    private String pretty(Material m) {
        String s = m.name().toLowerCase().replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
