package studio.spark.clickshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class ClickShop extends JavaPlugin {

    private static ClickShop instance;
    private Economy economy;
    private ShopManager shopManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        if (!setupEconomy()) {
            getLogger().severe("Vault + an economy plugin are required! Disabling ClickShop.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        shopManager = new ShopManager(this);
        shopManager.load();

        getServer().getPluginManager().registerEvents(new ShopListener(this), this);
        getLogger().info("ClickShop enabled.");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("shopreload")) {
            if (!sender.hasPermission("clickshop.admin")) {
                sender.sendMessage("§cNo permission.");
                return true;
            }
            reloadConfig();
            shopManager.load();
            sender.sendMessage("§aClickShop reloaded.");
            return true;
        }
        // /shop
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can open the shop.");
            return true;
        }
        if (!player.hasPermission("clickshop.use")) {
            player.sendMessage("§cNo permission.");
            return true;
        }
        shopManager.openMainMenu(player);
        return true;
    }

    public static ClickShop get() { return instance; }
    public Economy getEconomy() { return economy; }
    public ShopManager getShopManager() { return shopManager; }
}
