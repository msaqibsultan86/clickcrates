package studio.spark.clickshop;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Loads shop categories + items from config and builds the GUIs. */
public class ShopManager {

    private final ClickShop plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();

    public static final String MAIN_TITLE = ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "ClickShop";

    public ShopManager(ClickShop plugin) { this.plugin = plugin; }

    public record ShopItem(Material material, double buyPrice, double sellPrice) {}
    public static class Category {
        public String id, name;
        public Material icon;
        public int slot;
        public List<ShopItem> items = new ArrayList<>();
    }

    public void load() {
        categories.clear();
        ConfigurationSection cats = plugin.getConfig().getConfigurationSection("categories");
        if (cats == null) return;

        for (String key : cats.getKeys(false)) {
            ConfigurationSection c = cats.getConfigurationSection(key);
            if (c == null) continue;
            Category cat = new Category();
            cat.id = key;
            cat.name = ChatColor.translateAlternateColorCodes('&', c.getString("name", key));
            cat.icon = matOr(c.getString("icon"), Material.CHEST);
            cat.slot = c.getInt("slot", 0);

            ConfigurationSection items = c.getConfigurationSection("items");
            if (items != null) {
                for (String im : items.getKeys(false)) {
                    ConfigurationSection is = items.getConfigurationSection(im);
                    if (is == null) continue;
                    Material mat = matOr(im, null);
                    if (mat == null) continue;
                    cat.items.add(new ShopItem(mat,
                            is.getDouble("buy", -1),
                            is.getDouble("sell", -1)));
                }
            }
            categories.put(key, cat);
        }
        plugin.getLogger().info("Loaded " + categories.size() + " shop categories.");
    }

    private Material matOr(String name, Material def) {
        if (name == null) return def;
        Material m = Material.matchMaterial(name.toUpperCase());
        return m != null ? m : def;
    }

    /** Main menu: one icon per category. */
    public void openMainMenu(Player player) {
        int size = 27;
        Inventory inv = Bukkit.createInventory(null, size, MAIN_TITLE);
        for (Category cat : categories.values()) {
            ItemStack icon = new ItemStack(cat.icon);
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(cat.name);
                List<String> lore = new ArrayList<>();
                lore.add(ChatColor.GRAY + "Click to browse");
                lore.add(ChatColor.DARK_GRAY + String.valueOf(cat.items.size()) + " items");
                meta.setLore(lore);
                icon.setItemMeta(meta);
            }
            int slot = Math.max(0, Math.min(size - 1, cat.slot));
            inv.setItem(slot, icon);
        }
        player.openInventory(inv);
    }

    /** Category view: items with buy/sell prices in the lore. */
    public void openCategory(Player player, String catId) {
        Category cat = categories.get(catId);
        if (cat == null) return;
        int rows = Math.max(1, (int) Math.ceil(cat.items.size() / 9.0));
        int size = Math.min(54, rows * 9 + 9);
        Inventory inv = Bukkit.createInventory(null, size, categoryTitle(cat));

        int i = 0;
        for (ShopItem si : cat.items) {
            ItemStack it = new ItemStack(si.material());
            ItemMeta meta = it.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                if (si.buyPrice() >= 0)
                    lore.add(ChatColor.GREEN + "Buy: " + ChatColor.WHITE + fmt(si.buyPrice()));
                if (si.sellPrice() >= 0)
                    lore.add(ChatColor.RED + "Sell: " + ChatColor.WHITE + fmt(si.sellPrice()));
                lore.add(" ");
                lore.add(ChatColor.GRAY + "Left-click: buy 1");
                lore.add(ChatColor.GRAY + "Right-click: sell 1");
                meta.setLore(lore);
                it.setItemMeta(meta);
            }
            inv.setItem(i++, it);
        }
        player.openInventory(inv);
    }

    public String categoryTitle(Category cat) {
        return ChatColor.DARK_GREEN + "Shop " + ChatColor.DARK_GRAY + "» " + ChatColor.stripColor(cat.name);
    }

    public Category categoryByTitle(String title) {
        for (Category c : categories.values()) {
            if (categoryTitle(c).equals(title)) return c;
        }
        return null;
    }

    public Map<String, Category> getCategories() { return categories; }

    public static String fmt(double v) {
        if (v == Math.floor(v)) return "$" + (long) v;
        return String.format("$%.2f", v);
    }
}
